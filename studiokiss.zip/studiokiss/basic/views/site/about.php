<?php
use yii\helpers\Url;
?>

<h1>О нас</h1>

<img class="about-img" src="<?= Url::toRoute(['/images/about.jpg']) ?>" alt="about.jpg">

<div class="about-text-div">
    <p class="about-description">Наши студии отличаются хорошим качеством и большим пространством! Мы гарантируем Вам лучшую фотосессию с индивидуальным подходом к каждой фотографии!</p>
    <p class="about-description">Выбирайте лучшее!</p>
</div>
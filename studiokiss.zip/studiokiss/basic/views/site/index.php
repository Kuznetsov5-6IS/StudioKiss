<?php
use yii\helpers\Url;
?>

<h1>Галерея работ</h1>

<div class="studios-div">

    <div class="gallery-first-img-div"></div>

    <div class="gallery-second-img-div"></div>

    <div class="gallery-third-img-div"></div>

</div>

<h1>Наши услуги</h1>

<div class="services-div">

    <div class="service-card-div">
        <img class="service-img-div" src="<?= Url::toRoute(['/images/gray.jpg']) ?>" alt="gray.jpg">

        <div class="service-name-text-div"><p class="service-name-text">Фон бумажный Superior Neutral 2.7*11м</p></div>

        <div class="service-description-text-div"><p class="service-description-text">Бумажные фоны Superior им...</p></div>

        <div class="service-price-text-div"><p class="service-price-text">6440 <a class="price-gray-text">руб</a></p></div>

        <button class="button-to-buy-service">Купить</button>

    </div>



    <div class="service-card-div">
        <img class="service-img-div" src="<?= Url::toRoute(['/images/white.jpg']) ?>" alt="white.jpg">

        <div class="service-name-text-div"><p class="service-name-text">Фон бумажный Superior Neutral 2.7*11м</p></div>

        <div class="service-description-text-div"><p class="service-description-text">Бумажные фоны Superior им...</p></div>

        <div class="service-price-text-div"><p class="service-price-text">6440 <a class="price-gray-text">руб</a></p></div>

        <button class="button-to-buy-service">Купить</button>

    </div>


    <div class="service-card-div">
        <img class="service-img-div" src="<?= Url::toRoute(['/images/pink.jpg']) ?>" alt="pink.jpg">

        <div class="service-name-text-div"><p class="service-name-text">Фон бумажный Superior Neutral 2.7*11м</p></div>

        <div class="service-description-text-div"><p class="service-description-text">Бумажные фоны Superior им...</p></div>

        <div class="service-price-text-div"><p class="service-price-text">6440 <a class="price-gray-text">руб</a></p></div>

        <button class="button-to-buy-service">Купить</button>

    </div>


</div>


<h1>Интерьерные студии</h1>

<div class="studios-div">

    <div class="studio-first-img-div"><div class="studio-content-section">

        <p class="studio-name-text">Студия "Рельеф"</p>

        <p class="studio-description-text">Фотосессия у орнаметной стены</p>

        <p class="studio-price-text">19899 руб</p>

        <button class="studio-button-join">Заказать</button>

    </div></div>

    <div class="studio-second-img-div"><div class="studio-content-section">

    <p class="studio-name-text">Студия "Облако"</p>

        <p class="studio-description-text">Фотосессия в расслабленной обстановке</p>

        <p class="studio-price-text">12999 руб</p>

        <button class="studio-button-join">Заказать</button>

    </div></div>
    
    <div class="studio-third-img-div"><div class="studio-content-section">

    <p class="studio-name-text">Студия "Вдох"</p>

        <p class="studio-description-text">Фотосессия на фоне шикарной постели</p>

        <p class="studio-price-text">17999 руб</p>

        <button class="studio-button-join">Заказать</button>

    </div></div>
  

</div>

<h1>О нас</h1>


<div class="info-about-company-div"><p class="info-about-company">Наша компания занимается созданием только самых качественных снимков персонально для Вас! На данный момент кол-во наших клиентов насчитывает 50.000 человек! И все они очень довольны нашими услугами, которые мы предоставляем им!</p></div>

<div class="info-text-div"><p class="info-text">Наши контактные данные: </p></div>

<p class="info-address">Адрес: г. Богородск, ул. Апельсиновая, д. 52</p>
<p class="info-phone">Телефон: + 8 (999) 999 - 79 - 79</p>
<p class="info-email">Email: studiokiss@gmail.com</p>

<h1>Заказать мероприятие</h1>

<div class="next-fields-text-div"><p class="next-fields-text">Заполните следующие поля: </p></div>

<form class="form-order" action="" method="get">
    <p class="name-text">Название мероприятия: </p>
    <input type="text" class="name" placeholder="День города" autofocus="on"><br>
    <p class="fio-text">ФИО: </p>
    <input type="text" class="fio" placeholder="Иванов Иван Иванович"><br>
    <p class="tel-text">Телефон: </p>
    <input type="tel" class="phone" placeholder="+ 8 (999) 999 - 79 - 79"><br>
    <p class="email-text">Почта: </p>
    <input type="text" class="email" placeholder="studiokiss@gmail.com"><br>
    <p class="date-text">Предполагаемая дата: </p>
    <input type="date" class="date"><br>
    <button class="button-to-order">Заказать</button>
</form>
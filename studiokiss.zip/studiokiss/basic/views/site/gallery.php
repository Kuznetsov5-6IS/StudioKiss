<?php
use yii\helpers\Url;
?>

<h1>Галерея работ</h1>

<div class="studios-div">

    <div class="gallery-first-img-div"></div>

    <div class="gallery-second-img-div"></div>

    <div class="gallery-third-img-div"></div>

</div>
<?php
use yii\helpers\Url;
?>

<h1>Интерьерные студии</h1>

<div class="studios-div">

    <div class="studio-first-img-div"><div class="studio-content-section">

        <p class="studio-name-text">Студия "Рельеф"</p>

        <p class="studio-description-text">Фотосессия у орнаметной стены</p>

        <p class="studio-price-text">19899 руб</p>

        <button class="studio-button-join">Заказать</button>

    </div></div>

    <div class="studio-second-img-div"><div class="studio-content-section">

    <p class="studio-name-text">Студия "Облако"</p>

        <p class="studio-description-text">Фотосессия в расслабленной обстановке</p>

        <p class="studio-price-text">12999 руб</p>

        <button class="studio-button-join">Заказать</button>

    </div></div>
    
    <div class="studio-third-img-div"><div class="studio-content-section">

    <p class="studio-name-text">Студия "Вдох"</p>

        <p class="studio-description-text">Фотосессия на фоне шикарной постели</p>

        <p class="studio-price-text">17999 руб</p>

        <button class="studio-button-join">Заказать</button>

    </div></div>
  

</div>
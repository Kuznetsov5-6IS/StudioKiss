<?php
use yii\helpers\Url;
?>

<div class="services-div">

    <div class="service-card-div">
        <img class="service-img-div" src="<?= Url::toRoute(['/images/gray.jpg']) ?>" alt="gray.jpg">

        <div class="service-name-text-div"><p class="service-name-text">Фон бумажный Superior Neutral 2.7*11м</p></div>

        <div class="service-description-text-div"><p class="service-description-text">Бумажные фоны Superior им...</p></div>

        <div class="service-price-text-div"><p class="service-price-text">6440 <a class="price-gray-text">руб</a></p></div>

        <button class="button-to-buy-service">Купить</button>

    </div>



    <div class="service-card-div">
        <img class="service-img-div" src="<?= Url::toRoute(['/images/white.jpg']) ?>" alt="white.jpg">

        <div class="service-name-text-div"><p class="service-name-text">Фон бумажный Superior Neutral 2.7*11м</p></div>

        <div class="service-description-text-div"><p class="service-description-text">Бумажные фоны Superior им...</p></div>

        <div class="service-price-text-div"><p class="service-price-text">6440 <a class="price-gray-text">руб</a></p></div>

        <button class="button-to-buy-service">Купить</button>

    </div>


    <div class="service-card-div">
        <img class="service-img-div" src="<?= Url::toRoute(['/images/pink.jpg']) ?>" alt="pink.jpg">

        <div class="service-name-text-div"><p class="service-name-text">Фон бумажный Superior Neutral 2.7*11м</p></div>

        <div class="service-description-text-div"><p class="service-description-text">Бумажные фоны Superior им...</p></div>

        <div class="service-price-text-div"><p class="service-price-text">6440 <a class="price-gray-text">руб</a></p></div>

        <button class="button-to-buy-service">Купить</button>

    </div>


</div>
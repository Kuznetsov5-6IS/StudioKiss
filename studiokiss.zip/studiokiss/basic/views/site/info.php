<h1>Контакты</h1>

<div class="info-about-company-div"><p class="info-about-company">Наша компания занимается созданием только самых качественных снимков персонально для Вас! На данный момент кол-во наших клиентов насчитывает 50.000 человек! И все они очень довольны нашими услугами, которые мы предоставляем им!</p></div>

<div class="info-text-div"><p class="info-text">Наши контактные данные: </p></div>

<p class="info-address">Адрес: г. Богородск, ул. Апельсиновая, д. 52</p>
<p class="info-phone">Телефон: + 8 (999) 999 - 79 - 79</p>
<p class="info-email">Email: studiokiss@gmail.com</p>
<h1>Заказать мероприятие</h1>

<div class="next-fields-text-div"><p class="next-fields-text">Заполните следующие поля: </p></div>

<form action="" method="get">
    <p class="name-text">Название мероприятия: </p>
    <input type="text" class="name" placeholder="День города" autofocus="on"><br>
    <p class="fio-text">ФИО: </p>
    <input type="text" class="fio" placeholder="Иванов Иван Иванович"><br>
    <p class="tel-text">Телефон: </p>
    <input type="tel" class="phone" placeholder="+ 8 (999) 999 - 79 - 79"><br>
    <p class="email-text">Почта: </p>
    <input type="text" class="email" placeholder="studiokiss@gmail.com"><br>
    <p class="date-text">Предполагаемая дата: </p>
    <input type="date" class="date"><br>
    <button class="button-to-order">Заказать</button>
</form>